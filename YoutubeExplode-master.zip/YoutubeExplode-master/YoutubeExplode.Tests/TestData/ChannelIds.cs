﻿namespace YoutubeExplode.Tests.TestData
{
    internal static class ChannelIds
    {
        public const string Normal = "UCEnBXANsKmyj2r9xVyKoDiQ";
    }
}