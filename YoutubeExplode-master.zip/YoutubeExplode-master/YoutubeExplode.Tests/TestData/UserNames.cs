﻿namespace YoutubeExplode.Tests.TestData
{
    internal static class UserNames
    {
        public const string Normal = "TheTyrrr";
    }
}